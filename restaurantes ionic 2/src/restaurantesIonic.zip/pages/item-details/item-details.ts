import { Component } from '@angular/core';
import {RestauranteService} from "../../app/services/restaurante.service";


import { NavController, NavParams, Platform, ActionSheetController } from 'ionic-angular';


@Component({
  selector: 'item-details-page',
  templateUrl: 'item-details.html',
  providers: [RestauranteService]
})
export class ItemDetailsPage {
  selectedItem: any;
  public status: string;
	public errorMessage;

  constructor(public navCtrl: NavController, public navParams: NavParams,
  	public platform: Platform,
    public actionsheetCtrl: ActionSheetController,
    private _restauranteService: RestauranteService) {
    // If we navigated to this page, we will have an item available as a nav param
    this.selectedItem = navParams.get('item');
  }

    openMenu() {
    let actionSheet = this.actionsheetCtrl.create({
      title: 'Opciones Restaurante',
      cssClass: 'action-sheets-basic-page',
      buttons: [
        {
          text: 'Eliminar',
          role: 'destructive',
          icon: !this.platform.is('ios') ? 'trash' : null,
          handler: () => {
            console.log('Delete clicked: '+this.selectedItem.id);
            this._restauranteService.deleteRestaurante(this.selectedItem.id)
            	.subscribe(
							result => {
									this.status = result.status;

									if(this.status !== "success"){
										alert("Error en el servidor");
									}
									else {console.log('Restaurante Eliminado');}
									this.navCtrl.popToRoot();
									

							},
							error => {
								this.errorMessage = <any>error;
								
								if(this.errorMessage !== null){
									console.log(this.errorMessage);
									alert("Error en la petición");
								}
							}
						);
          }
        },
        {
          text: 'Editar',
          icon: !this.platform.is('ios') ? 'paper' : null,
          handler: () => {
            console.log('Share clicked');
            this.navCtrl.popToRoot();
          }
        },
        
        
        {
          text: 'Cancelar',
          role: 'cancel', // will always sort to be on the bottom
          icon: !this.platform.is('ios') ? 'close' : null,
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    actionSheet.present();
  }
}
