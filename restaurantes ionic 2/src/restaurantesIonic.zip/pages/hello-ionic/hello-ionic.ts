import { Component } from '@angular/core';
import {RestauranteService} from "../../app/services/restaurante.service";
import {Restaurante} from "../../app/model/restaurante";

import { NavController, NavParams} from 'ionic-angular';
import { ItemDetailsPage } from '../item-details/item-details';


@Component({
  selector: 'hello-ionic-page',
  templateUrl: 'hello-ionic.html',
  providers: [RestauranteService]
})
export class RestaurantesListComponent  {
	private titulo:string;
	public restaurantes: Restaurante[];
	public status: string;
	public errorMessage;
	public confirmado;
	public loading;

	constructor(
		private _restauranteService: RestauranteService,public navCtrl: NavController, public navParams: NavParams

		){
		this.titulo="Listado";
	}
	ionViewWillEnter (){
		console.log('Pagina principal activa');
		this.getRestaurantes();
	}
	ngOnInit() {
		this.loading = 'show';
 		this.getRestaurantes();
		console.log("restaurantes-list component cargado");
	}

	getRestaurantes(){
		
		this._restauranteService.getRestaurantes()
				.subscribe(
					result => {
							this.restaurantes = result.data;
							this.status = result.status;

							if(this.status !== "success"){
								alert("Error en el servidor");
							}

							this.loading = 'hide';
					},
					error => {
						this.errorMessage = <any>error;
						
						if(this.errorMessage !== null){
							console.log(this.errorMessage);
							alert("Error en la petición");
						}
					}
				);
			}
	onBorrarConfirm(id){
		this.confirmado = id;
	}

	onCancelarConfirm(id){
		this.confirmado = null;
	}

	onBorrarRestaurante(id){
		console.warn('Borrando restaurante');
			this._restauranteService.deleteRestaurante(id)
						.subscribe(
							result => {
									this.status = result.status;

									if(this.status !== "success"){
										alert("Error en el servidor");
									}
									this.getRestaurantes();

							},
							error => {
								this.errorMessage = <any>error;
								
								if(this.errorMessage !== null){
									console.log(this.errorMessage);
									alert("Error en la petición");
								}
							}
						);
	}
	 itemTapped(event, restaurante) {
    this.navCtrl.push(ItemDetailsPage, {
      item: restaurante
    });
  }

		
}